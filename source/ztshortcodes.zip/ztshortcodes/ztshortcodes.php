<?php

/**
 * Zt Shortcodes
 * A powerful Joomla plugin to help effortlessly customize your own content and style without HTML code knowledge
 * 
 * @name        Zt Shortcodes
 * @version     2.0.0
 * @package     Plugin
 * @subpackage  System
 * @author      ZooTemplate 
 * @email       support@zootemplate.com 
 * @link        http://www.zootemplate.com 
 * @copyright   Copyright (c) 2015 ZooTemplate
 * @license     GPL v2 
 */
defined('_JEXEC') or die('Restricted access');


jimport('joomla.plugin.plugin');

/**
 * Class exists checking
 */
if (!class_exists('plgSystemZtShortcodes'))
{

    /**
     * 
     */
    class plgSystemZtShortcodes extends JPlugin
    {

        /**
         * 
         * @param type $subject
         * @param type $config
         */
        public function __construct(&$subject, $config = array())
        {
            parent::__construct($subject, $config);
            require_once __DIR__ . '/core/bootstrap.php';
        }

        /**
         * Service for backend request
         */
        public function onAfterRoute()
        {
            $jinput = JFactory::getApplication()->input;
            if ($task = $jinput->get('ztshortcodes_task'))
            {
                $view = $jinput->get('ztshortcodes_view');
                $html = new ZtShortcodesHtml();
                $buffer = $html->fetch('Shortcodes://html/admin/' . $view . '.php');
                echo $buffer;
                exit();
            }
        }

        /**
         * 
         */
        public function onAfterRender()
        {
            // Only process for frontend
            if (JFactory::getApplication()->isSite())
            {
                require_once __DIR__ . '/core/bootstrap.php';
                $template = JFactory::getApplication()->getTemplate();
                $templateDir = JPATH_ROOT . '/templates/' . $template . '/html/plg_system_ztshortcodes';
                ZtShortcodesPath::getInstance()->registerNamespace('Shortcodes', $templateDir);
                // Get body
                $html = JResponse::getBody();
                $parser = ZtShortcodesParser::getInstance();
                // Execute shortcodes
                $html = $parser->do_shortcode($html);
                // Set back to Joomla!
                JResponse::setBody($html);
            }
        }

        /**
         * 
         * @return array
         */
        private function _getShortcodes()
        {
            $jsonFile = ZtShortcodesPath::getInstance()->getPath('Shortcodes://assets/shortcodes.json');
            if ($jsonFile)
            {
                return json_decode(file_get_contents($jsonFile), true);
            }
            return array();
        }

    }

}